

var app = angular.module('myApp',[]);
app.controller('mainController', function($scope,$http){



$scope.findContacts=function(){
$http.get('/contactList').success(function(response){
	console.log('i received the data' + JSON.stringify(response));
	$scope.contacts='';
	$scope.contacts=response;

}, function(error){
	console.log(error);
});
}
// fetch all contacts at init 
$scope.findContacts();


$scope.addContact=function(){
	$http.post("/addContact", $scope.contact).success(function(response){
		console.log(JSON.stringify(response));
	});
	$scope.findContacts();
	$scope.contact='';
}


$scope.deleteContact=function(id){
	console.log(id);
	$http.delete('/deleteContact/'+id).success(function(response){
		console.log(response);
	});
	$scope.findContacts();
}



});
