var express =require('express');
var app =express();
var mongo= require('mongojs');
var db = mongo('192.168.2.62/dev', ['contact']);
var bodyParser=require('body-parser');




app.use(express.static(__dirname +"/public"));
app.use(bodyParser.json());

app.get('/contactList',function(request, response){
	db.contact.find(function (err, docs) {
		console.log(docs);
		console.log(err);
	});
});


app.post('/addContact', function(request,response){
	console.log("server.js addContact");
	console.log(request.body);
	var data = request.body;
	db.contact.insert(request.body,function(err, docs){
		console.log(docs);
		console.log(err);
	});
	
});


app.delete('/deleteContact/:id',function(request,response){
	console.log("server delete hit..");
	console.log(request.params.id);
	var id =request.params.id;
	db.contact.remove({_id:mongo.ObjectId(id)}, function(err,docs){
		console.log(docs);
		console.log(err);
	});

	
});


app.listen(3000);
console.log('server is running on 3000 port');